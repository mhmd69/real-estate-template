# Editing content and listings

## Pages and appearance

Edit the relevant `dist/<route>/index.html`; the home page is `dist/index.html`. Shared base colors are CSS custom properties at the beginning of `styles.css`. Full-site layout overrides are in `website.css`. Changes to shared HTML such as phone numbers and navigation must be applied across all pages.

## Real property data

Edit `dist/properties.js`. Populate `window.MIDDLE_EAST_PROPERTIES`; keep the separately labeled example array separate. Use verified property information and photographs.

```js
window.MIDDLE_EAST_PROPERTIES = [
  {
    id: "your-property-id",
    title: "Your verified property title",
    location: "Actual area, Lebanon",
    category: "Apartments",
    type: "sale",
    price: 150000,
    bedrooms: 2,
    bathrooms: 1,
    image: "/assets/your-property.jpg",
    url: "https://your-domain.example/property-details"
  }
];
```

This is a schema example, not an actual listing. Numeric fields must be numbers. Use `sale` or `rent` for `type`. Rental prices are currently displayed per month. For “5+” bedrooms/bathrooms, the filter matches values of five and above. Other bedroom/bathroom filters match exactly.

Category strings must match the filter values:

- Stylish Houses
- Luxury Houses
- Apartments
- Deluxe Houses
- Beach Villas
- Modern Lofts
- Country Homes
- Urban Studios

Order real properties newest first to control the “Latest first” view. Real property cards link their titles to `url` when supplied. If your site needs its own real-property detail pages, implement those pages or extend the existing example dialog to verified data.

## Contact and account destinations

Contact details are in page HTML, footer copies, and `site.js`. WhatsApp drafts currently use `96170206032`. Existing sign-in points to `https://middleast.vercel.app/login`. Changing labels alone does not change these JavaScript destinations.

## Images

Place new images in `dist/assets/` and reference them with `/assets/filename.ext`. Use descriptive alternative text. Existing architectural photographs came from the reference site's Unsplash URLs; the logo came from its `real.gif`. Confirm suitable image and brand rights before a separate public launch. Team initials are used instead of fabricated portraits.
