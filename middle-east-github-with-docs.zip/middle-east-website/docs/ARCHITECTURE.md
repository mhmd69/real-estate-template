# Architecture

## Stack

HTML5, CSS, and vanilla JavaScript. No frontend framework, production packages, build step, database, or server application is required. Python is used only as an optional local HTTP server. The existing preview is hosted on ChatGPT Sites; this export works with static hosting at a domain root.

## Structure

| Path | Responsibility |
| --- | --- |
| `dist/index.html` | Home page |
| `dist/<route>/index.html` | Separate public pages |
| `dist/styles.css` | Original collection layout and shared base styles |
| `dist/website.css` | Full website styles, components, and breakpoints |
| `dist/site.js` | Navigation, home galleries, contact drafts, request wizard |
| `dist/app.js` | Collection filtering, sorting, example-detail dialog |
| `dist/properties.js` | Public listing array and opt-in example array |
| `dist/assets/` | Logo and architectural imagery |

HTML headers and footers are repeated per page. Update all page copies when changing navigation, contact details, or shared footer content. JavaScript uses native DOM APIs and CSS uses media queries, grid, flexbox, and reduced-motion overrides.

## Data flow

1. Collection HTML loads `site.js`, `properties.js`, then `app.js`.
2. `app.js` reads `MIDDLE_EAST_PROPERTIES` for public listings.
3. The example toggle switches to the separate `MIDDLE_EAST_EXAMPLES` array.
4. Filters run in the browser. Search state is reflected in URL query parameters.
5. The example gallery uses a native HTML `dialog` and local images.

There are no API calls for property retrieval or authentication. Data is not synchronized between devices.

## Request flow

The three-step form validates contact information and property fields, constructs a review, and opens an encoded WhatsApp draft. Images use local object URLs for preview. Images are not uploaded or included in the WhatsApp URL. The visitor attaches them manually in WhatsApp. Contact messages similarly open WhatsApp or email drafts.

## Current limits

- No database, admin dashboard, account creation, local sign-in, payment processing, or server-side submissions.
- Existing-account sign-in links to the original service.
- Plans are displayed as coming soon.
- No actual public listings were available when the reference was inspected.
- The detail dialog is implemented for examples; real listings can link to their own `url`.
- “Latest first” preserves the order supplied in the data array.
- Request drafts are not stored; refreshing the page clears unsent form state.
