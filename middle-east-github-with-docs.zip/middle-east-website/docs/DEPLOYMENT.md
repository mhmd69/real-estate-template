# Running and deployment

## Local development

From the repository root:

```sh
python3 -m http.server 4173 --directory dist
```

Visit `http://localhost:4173`. No npm installation is needed. Opening HTML directly with `file://` will not correctly resolve root-relative links.

## Static hosting

Publish directory: `dist`.
Build command: none.
Environment variables: none.

Serve the site at the domain root, with directory-index support (`/pricing/` serves `dist/pricing/index.html`). Do not add a blanket single-page-app rewrite: the project has actual HTML files for every route. Use `dist/404.html` as the host's custom not-found page where supported.

The included `netlify.toml` specifies the `dist` publish directory. It does not trigger a deployment until the repository is connected to a Netlify site. On other static hosts, use equivalent root-directory and publish-directory settings.

GitHub repository Pages URLs usually include a repository-name path prefix. This project uses root-relative links; use a root-domain deployment or update every root-relative HTML, CSS, and JavaScript URL before hosting beneath a subpath.

## Pre-launch checks

- Open all eight routes and the missing-page fallback.
- Check navigation at desktop and phone widths.
- Test hero slides and category scrolling.
- Enable examples, combine filters, sort prices, and open a gallery.
- Check minimum/maximum price validation and reset.
- Complete both request modes and inspect the WhatsApp draft before sending.
- Test contact draft destinations without sending test messages to the business.
- Verify actual listing data, business details, pricing availability, and asset permissions.

Earlier interaction logic checks passed for navigation, carousels, filters, sorting, example dialogs, form validation, wizard review, and draft generation. Those checks were DOM-based. A full browser visual/mobile QA pass remains recommended before a public launch.
