# Backend integration plan

This document describes future work. None of the endpoints or storage below exists in the current frontend.

## Suggested integration boundary

Keep the current static frontend and connect a separate API, or migrate the UI into a full-stack application when account and administration requirements are defined. Reuse the original backend if its owner supplies documented, authorized API access. Never copy private database contents or authentication secrets into browser files.

## Required capabilities

| Capability | Work needed |
| --- | --- |
| Public listings | Database, listing status, pagination, filters, validated public read API |
| Listing management | Authenticated admin editor, publishing controls, access checks |
| Property detail pages | Stable IDs/slugs, verified images, canonical links |
| Accounts | Real authentication, session handling, recovery, role-based authorization |
| Requests | Server validation, persistence, admin inbox, delivery/retry status |
| Photo uploads | Object storage, file validation, size limits, authenticated uploads |
| Contact delivery | Server-side email service, rate limiting and spam controls |
| Subscriptions | Approved availability and billing rules before payment integration |

## Possible API contract

- `GET /api/properties`: published listings only, with filtering and pagination.
- `GET /api/properties/:id`: one public listing.
- `POST /api/requests`: validated buyer/seller inquiry.
- `POST /api/contact`: validated contact message.
- Admin listing and request endpoints: protected by server-side roles.

Define the final schema, response format, error cases, and privacy/retention requirements before implementation. Public APIs must exclude owner-only contact fields and unpublished inventory.

## Frontend connection points

Replace the static public array in `properties.js` with a loader and explicit loading/error/empty states. Adapt filtering and counts for server pagination. Replace WhatsApp/email draft handlers in `site.js` only after real endpoints exist; show success only when the server confirms persistence. Integrate uploads independently from textual submission and provide retry behavior.

For accounts, replace the current external login link only after a working authentication system is configured. Do not simulate successful sign-in or store passwords in JavaScript or local storage.
