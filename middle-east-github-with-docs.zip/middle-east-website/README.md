# Middle East Real Estate

A complete static recreation of the public Middle East website, with a refreshed blue-and-white responsive design.

## Run locally

From this directory, run:

```sh
python3 -m http.server 4173 --directory dist
```

Open http://localhost:4173. Upload the contents of `dist` to any static web host to deploy. No installation or compilation is required. Because links use root-relative paths, serve the site over HTTP rather than opening HTML files directly.

## Pages

- `/`: homepage, image carousel, category carousel, property search, services
- `/properties/`: search and filters, sort, optional example collection, property detail gallery
- `/pricing/`: original four plans, expandable comparison and FAQs
- `/about-us/`: company story, mission, values, leadership
- `/support/`: contact information, validated WhatsApp and email draft creation
- `/post-request/`: buy/sell request wizard, specifications, local image previews, request review, WhatsApp draft
- `/login/`: account-access page linking to the existing original authentication service
- `/sitemap/`: page navigation
- `404.html`: fallback page

## Data and integrations

Reference: https://middleast.vercel.app/ (inspected 28 September 2026).
The reference website displayed no public properties. `dist/properties.js` therefore contains an empty real-property array and a separate clearly labeled opt-in example array. Example prices and details are illustrative, not actual offers. Add verified listings to `MIDDLE_EAST_PROPERTIES` or integrate your API in `app.js`.

This is a frontend recreation. It does not copy or access the original database or private admin dashboard. Existing-account authentication continues on the original site. No passwords are collected by this recreation.

Contact and request forms open WhatsApp/email drafts for the visitor to send. They do not silently submit to a server. Property photos are previewed on the visitor's device only, and must be attached separately in WhatsApp. No backend storage or email delivery service is configured.

Subscription prices and features follow the original page. Plans remain marked coming soon, and no payments are collected. The contact details, team names, and history come from the original public pages. A mistyped phone link on the original contact page was normalized to match its visible number and repeated footer number.

## Files

- `dist/styles.css`: base collection and shared navigation styles
- `dist/website.css`: complete responsive website design
- `dist/site.js`: shared interactions, contact flow, request wizard
- `dist/app.js`: property browsing, filters, modal galleries
- `dist/properties.js`: real and example data
- `dist/assets/`: downloaded reference-site logo and architectural imagery

Images are sourced from the reference website's image URLs. No fabricated team portraits are used.

## Documentation

- [Architecture and limitations](docs/ARCHITECTURE.md)
- [Editing content and property data](docs/CONTENT_GUIDE.md)
- [Local setup and deployment](docs/DEPLOYMENT.md)
- [Future backend integration](docs/BACKEND_PLAN.md)

## Hosting configuration

`netlify.toml` publishes `dist` with no build command. No environment variables are required. Root-relative links require deployment at a domain root; see the deployment guide for GitHub Pages subpath considerations.
